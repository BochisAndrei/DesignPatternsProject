public class Paragraph {
    protected String paragraph;

    public Paragraph(String nume){
        this.paragraph=nume;
    }

    @Override
    public String toString() {
        return "Paragraph{" +
                "paragraph='" + paragraph + '\'' +
                '}';
    }
}
