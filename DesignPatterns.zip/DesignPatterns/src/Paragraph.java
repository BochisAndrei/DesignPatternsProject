public class Paragraph implements Element{
    protected String paragraph;
    protected AlignStrategy align;

    public Paragraph(String nume){
        this.paragraph=nume;
    }



    @Override
    public String toString() {
        return "Paragraph{" +
                "paragraph='" + paragraph + '\'' +
                '}';
    }
    public void setAlignStrategy(AlignStrategy align){
        this.align = align;

    }
    public void print() {
        if(align!=null) align.print(paragraph);
        else System.out.println(paragraph);
    }
    public void accept(Visitor v){
        v.visit(this);
    }

}
