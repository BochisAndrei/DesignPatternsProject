public class Paragraph implements Element{
    protected String paragraph;

    public Paragraph(String nume){
        this.paragraph=nume;
    }

    @Override
    public String toString() {
        return "Paragraph{" +
                "paragraph='" + paragraph + '\'' +
                '}';
    }
    public void print(){
        System.out.println("Paragraph: " + paragraph);
    }
}
