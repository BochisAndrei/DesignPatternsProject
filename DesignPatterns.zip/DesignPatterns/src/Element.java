public abstract class Element {
    public void print(){};
}
