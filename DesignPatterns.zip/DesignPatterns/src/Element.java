public interface Element {
    public void print();
}
