public class ImageProxy implements Element{
    protected String imageName;
    protected Image realImage;
    public ImageProxy(String img){
        this.imageName = img;
    }
    public void print(){
        if(realImage == null){
            realImage = new Image(imageName);
        }
        realImage.print();
    }
}
