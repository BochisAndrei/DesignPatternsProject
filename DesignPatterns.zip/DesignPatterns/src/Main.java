import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        Command cmd1 = new OpenCommand("/Users/andreibochis/IdeaProjects/DesignPatterns/src/Book.json");
        cmd1.execute();
        Command cmd2 = new StatisticCommand(DocumentManager.getInstance().getBook());
        cmd2.execute();
        DocumentManager.getInstance().getBook().print();

    }

}

