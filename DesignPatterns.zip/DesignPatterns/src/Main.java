import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {

            Builder jsonBuilder = new JsonBuilder("/Users/andreibochis/IdeaProjects/DesignPatterns/src/Book.json");
            jsonBuilder.build();
            Element myBook = jsonBuilder.getResult();

            if(myBook != null) myBook.print();

    }

}

