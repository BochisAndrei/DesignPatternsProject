public class Main {

    public static void main(String[] args) {
        /*
        Book diseaTitanic = new Book("Disea Titanic");
        Author rPaul = new Author("Radu Paul");
        diseaTitanic.addAuthor(rPaul);
        int indexOfChapter = diseaTitanic.createChapter("Chapter One");
        Chapter chOne = diseaTitanic.getChapter(indexOfChapter);
        int indexOfSubChapter = chOne.createSubChapter("ChapterOneOne");
        SubChapter chOneOne = chOne.getSubChapter(indexOfSubChapter);
        int indexOfParagraph = chOneOne.createParagraph("Paragraph1");
        int indexOfImage = chOneOne.createImage("Image1");
        int indexOfTable = chOneOne.createTable("Table1");
        System.out.println(diseaTitanic);
        */

        Book discoTitanic = new Book("Disco Titanic");
        Author rpGheo = new Author("Radu Pavel Gheo");
        discoTitanic.addAuthor(rpGheo);
        int indexChapterOne = discoTitanic.createChapter("Capitolul 1");
        Chapter chp1 = discoTitanic.getChapter(indexChapterOne);
        int indexSubChapterOneOne = chp1.createSubChapter("Subcapitolul 1.1");

        SubChapter scOneOne = chp1.getSubChapter(indexSubChapterOneOne);
        scOneOne.createParagraph("Paragraph 1");
        scOneOne.createParagraph("Paragraph 2");
        scOneOne.createParagraph("Paragraph 3");
        scOneOne.createImage("Image 1");
        scOneOne.createParagraph("Paragraph 4");
        scOneOne.createTable("Table 1");
        scOneOne.createParagraph("Paragraph 5");

        scOneOne.print();
    }
}
