public interface AlignStrategy {
    public void print(String msg);
}
