public class AlignCenter implements AlignStrategy {

    public AlignCenter(){
    }
    public void print(String msg){
        System.out.println("+++++++" + msg + "+++++++" );
    }
}
