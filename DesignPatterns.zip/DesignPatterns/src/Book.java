import java.util.ArrayList;

public class Book {
    protected String nume;
    protected ArrayList<Author>  listaAutori = new ArrayList<Author>();
    protected ArrayList<Chapter> listaCapitole = new ArrayList<Chapter>();

    public Book(String nume){
        this.nume=nume;

    }
    public int createChapter(String chapterName){
        Chapter chr = new Chapter(chapterName);
        listaCapitole.add(chr);
        return listaCapitole.indexOf(chr);
    }
    public Chapter getChapter(int index){
        return listaCapitole.get(index);
    }
    public void addAuthor(String authorName){
        Author au = new Author(authorName);
        listaAutori.add(au);
    }
    public void addAuthor(Author au){
        listaAutori.add(au);
    }

    @Override
    public String toString() {
        return "Book{" +
                "nume='" + nume + '\'' +
                ", listaAutori=" + listaAutori +
                ", listaCapitole=" + listaCapitole +
                '}';
    }
}
