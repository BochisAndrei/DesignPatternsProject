import java.util.ArrayList;

public class SubChapter {
    protected String nume;
    protected ArrayList<Paragraph> listaParagrafe = new ArrayList<Paragraph>();;
    protected ArrayList<Image> listaImagini = new ArrayList<Image>();;
    protected ArrayList<Table> listaTabele = new ArrayList<Table>();;

    public SubChapter(String nume){
        this.nume=nume;
    }

    @Override
    public String toString() {
        return "SubChapter{" +
                "nume='" + nume + '\'' +
                ", listaParagrafe=" + listaParagrafe +
                ", listaImagini=" + listaImagini +
                ", listaTabele=" + listaTabele +
                '}';
    }

    public int createParagraph(String nume){
        Paragraph p = new Paragraph(nume);
        listaParagrafe.add(p);
        return listaParagrafe.indexOf(p);
    }
    public Paragraph getParagraph(int index){
        return listaParagrafe.get(index);
    }

    public int createImage(String nume){
        Image p = new Image(nume);
        listaImagini.add(p);
        return listaImagini.indexOf(p);
    }
    public Image getImage(int index){
        return listaImagini.get(index);
    }

    public int createTable(String nume){
        Table t = new Table(nume);
        listaTabele.add(t);
        return listaTabele.indexOf(t);
    }
    public Table getTable(int index){
        return listaTabele.get(index);
    }
}
