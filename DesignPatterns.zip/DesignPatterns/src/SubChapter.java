import java.util.ArrayList;

public class SubChapter {
    protected String nume;
    protected ArrayList<Element> listaElemente = new ArrayList<>();


    public SubChapter(String nume){
        this.nume=nume;
    }


    public void print(){
        System.out.println("Subchapter: " + nume);
        for (Element var : listaElemente)
        {
            var.print();
        }

    }

    public int createParagraph(String nume){
        Paragraph p = new Paragraph(nume);
        listaElemente.add(p);
        return listaElemente.indexOf(p);
    }
    public Paragraph getParagraph(int index){
        return (Paragraph) listaElemente.get(index);
    }

    public int createImage(String nume){
        Image p = new Image(nume);
        listaElemente.add(p);
        return listaElemente.indexOf(p);
    }
    public Image getImage(int index){
        return (Image) listaElemente.get(index);
    }

    public int createTable(String nume){
        Table t = new Table(nume);
        listaElemente.add(t);
        return listaElemente.indexOf(t);
    }
    public Table getTable(int index){
        return (Table) listaElemente.get(index);
    }

}
