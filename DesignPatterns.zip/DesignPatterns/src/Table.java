public class Table implements Element{
    protected String nume;

    @Override
    public String toString() {
        return "Table{" +
                "nume='" + nume + '\'' +
                '}';
    }

    public Table(String nume){
        this.nume = nume;
    }

    public void print(){
        System.out.println("Tabel with Title: " + nume);
    }
}
