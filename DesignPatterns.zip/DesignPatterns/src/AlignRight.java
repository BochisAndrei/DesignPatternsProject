public class AlignRight implements AlignStrategy {

    public AlignRight(){
    }
    public void print(String msg){
        System.out.println("+++++++++++++++" + msg );
    }
}
