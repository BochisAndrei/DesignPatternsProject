import java.util.ArrayList;

public class Chapter {
    protected String chapter;

    @Override
    public String toString() {
        return "Chapter{" +
                "chapter='" + chapter + '\'' +
                ", listaSubCapitole=" + listaSubCapitole +
                '}';
    }

    protected ArrayList<SubChapter> listaSubCapitole = new ArrayList<SubChapter>();;

    public Chapter(String nume){
        this.chapter=nume;
    }

    public int createSubChapter(String chapterName){
        SubChapter chr = new SubChapter(chapterName);
        listaSubCapitole.add(chr);
        return listaSubCapitole.indexOf(chr);
    }
    public SubChapter getSubChapter(int index){
        return listaSubCapitole.get(index);
    }
}
