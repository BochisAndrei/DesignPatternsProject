import java.util.ArrayList;

public class Section implements Element{
    protected String nume;
    protected ArrayList<Element> listaElemente = new ArrayList<Element>();

    public Section(String nume){
        this.nume=nume;
    }

    public void print(){
        System.out.println("Section: " + nume);
        for (Element var : listaElemente)
        {
            var.print();
        }

    }
    public int add(Element el){
        listaElemente.add(el);
        return listaElemente.indexOf(el);
    }

    public Element getElement(int index){
        return (Element) listaElemente.get(index);
    }
    public void removeSection(Element e){
        for (Element elm:listaElemente) {
            if(elm == e)
                listaElemente.remove(elm);
        }
    }


}
