public class DocumentManager {
    private static DocumentManager instance=null;
    protected Book myBook;

    private DocumentManager(){

    }

    public static DocumentManager getInstance(){
        if(instance==null){
            instance=new DocumentManager();
        }
        return instance;
    }
    public Book getBook(){
        Book b = new Book("Carte Goala");
        if(myBook!=null) return myBook;
        return b;
    }

    public void setBook(Book book){
        myBook=book;
    }

}
