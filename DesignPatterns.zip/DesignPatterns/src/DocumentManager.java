public class DocumentManager {
    private static DocumentManager instance=null;
    protected Book myBook;
    protected FirstObserver f = new FirstObserver();
    protected SecondObserver s = new SecondObserver();

    private DocumentManager(){

    }

    public static DocumentManager getInstance(){
        if(instance==null){
            instance=new DocumentManager();
        }
        return instance;
    }
    public Book getBook(){
        Book b = new Book("Carte Goala");
        if(myBook!=null) return myBook;
        return b;
    }
    public Observer getFirstObserver(){
        return f;
    }
    public Observer getSecondObserver(){
        return s;
    }

    public void setBook(Book book){
        myBook=book;
    }

}


