public class AlignLeft implements AlignStrategy {

    public AlignLeft(){
    }
    public void print(String msg){
        System.out.println(msg + "+++++++++++++++");
    }
}
