public interface Observer {
    public void update(String oldValue, String newValue);
}
