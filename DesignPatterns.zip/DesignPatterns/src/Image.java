public class Image {
    protected String image;

    @Override
    public String toString() {
        return "Image{" +
                "image='" + image + '\'' +
                '}';
    }

    public Image(String nume){
        this.image=nume;
    }
}
