public class Image extends Element{
    protected String image;

    @Override
    public String toString() {
        return "Image{" +
                "image='" + image + '\'' +
                '}';
    }

    public Image(String nume){
        this.image=nume;
    }

    public void print(){
        System.out.println("Imagine with name: " + image);
    }
}
