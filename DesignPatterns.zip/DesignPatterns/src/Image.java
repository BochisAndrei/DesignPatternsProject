import java.util.concurrent.TimeUnit;

public class Image implements Element{
    protected String image;

    @Override
    public String toString() {
        return "Image{" +
                "image='" + image + '\'' +
                '}';
    }

    public Image(String nume){

        this.image=nume;
        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void print(){
        System.out.println("Imagine with name: " + image);
    }
}
